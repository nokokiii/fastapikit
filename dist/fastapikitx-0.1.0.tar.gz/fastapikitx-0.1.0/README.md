# fastapi-utils
Utils classes and functions for creating FastAPI


## Instalation

```bash
pip install fastapikitx
```